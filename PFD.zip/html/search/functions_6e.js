var searchData=
[
  ['node',['node',['../structnode.html#a00490a4fdc36be462497c852dd431fef',1,'node::node(int nId, std::vector&lt; int &gt; out, std::vector&lt; int &gt; in)'],['../structnode.html#a00490a4fdc36be462497c852dd431fef',1,'node::node(int nId, std::vector&lt; int &gt; out, std::vector&lt; int &gt; in)']]]
];
